'''
Contine los algoritmos que calculan las optimas particiones recomendadas por cada indices de validacion interno calculado 
'''

import pandas as pd
import numpy as np 

def opt_partition_index(indices_V_I_pd, nom_col_partition, index):
    '''
    indices_V_I_pd: el dataframe con los valores de desempeño obtenidos por los indices de validacion internos
    nom_col_partition: contiene el nombre de la columna en el que estan el numero de particiones halladas
    index: nombre del indices de validacion interno analizar
    '''
    switch =  {
        'B_H': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 3),
        'B_R': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
        'C': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
        'CH': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'DB': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
        'D_R': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 4),
        'DI': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'gamma': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'G_mas': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
        'GDI11': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'GDI12': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'GDI13': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'GDI21': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'GDI22': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'GDI23': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'GDI31': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'GDI32': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'GDI33': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'GDI41': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'GDI42': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'GDI43': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'GDI51': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'GDI52': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'GDI53': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'K_D': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 3),
        'Log_D_R': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 4),
        'Log_B_W': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 4),
        'M_R': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
        'PBM': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'P_B': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'R_T': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
        'R_L': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'S_S': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
        'S_Dbw': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
        'Si': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'T_W': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 3),
        'T_WiB': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 3),
        'W_G': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'XB': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
        'PC': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'CE': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
        'G_str': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'G_rex': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'ICC': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'CV': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'SSDD': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
        'LCCV': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'DCVI': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
        'MPC': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'PBMF': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 1),
        'MPE': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
        'SD': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
        'CVNN': lambda: opt_partition(indices_V_I_pd, nom_col_partition, index, 2),
    }

    return switch.get(index,  lambda: 'NI')()

def partition_diff(indices_V_I_pd, nom_col_partition, index, max_min):
    '''
    indices_V_I_pd: el dataframe con los valores de desempeño obtenidos por los indices de validacion internos
    nom_col_partition: contiene el nombre de la columna en el que estan el numero de particiones halladas
    index: nombre del indices de validacion interno analizar
    max_min: indica el valor desempeño hallar que indice analizar sugiere (0: min_diff, 1: max_diff)
    '''
    x = indices_V_I_pd[nom_col_partition].tolist()
    y = (indices_V_I_pd[index].dropna()).to_list()

    if len(x) == len(y):
        m=[]
        for id_value in range(len(y)-1):
            m.append(x[id_value + 1])
            m.append(y[id_value + 1] - y[id_value])

        m = np.array(m)
        m = m.reshape(len(y)-1, 2)

        max_m=[]
        for id_value in range(len(m)-1):
            if abs(m[id_value,1]) >= abs(m[id_value + 1, 1]):
                max_m.append(m[id_value,0])
                max_m.append(abs(m[id_value,1])/abs(m[id_value + 1, 1]))
            else:
                max_m.append(m[id_value,0])
                max_m.append(abs(m[id_value + 1, 1])/abs(m[id_value,1]))
        
        max_m = np.array(max_m)
        max_m = max_m.reshape(len(m)-1, 2)
        max_m = pd.DataFrame(max_m)

        if max_min == 1:
            opt_partition_diff = max_m[0][max_m[1].idxmax()]
        else:
            opt_partition_diff = max_m[0][max_m[1].idxmin()]

    else:
        opt_partition_diff = "NaN"
    
    return opt_partition_diff

def opt_partition(indices_V_I_pd, nom_col_partition, index, max_min_diff):
    '''
    indices_V_I_pd: el dataframe con los valores de desempeño obtenidos por los indices de validacion internos
    nom_col_partition: contiene el nombre de la columna en el que estan el numero de particiones halladas
    index: nombre del indices de validacion interno analizar
    max_min_diff: indica el valor desempeño hallar que indice analizar sugiere (1: max, 1: min, 1: max_diff, 1: min_diff)
    '''
    if max_min_diff == 1:
        indx = indices_V_I_pd[index].idxmax()
        num_partition = indices_V_I_pd[nom_col_partition][indx]
    elif max_min_diff == 2:
        indx = indices_V_I_pd[index].idxmin()
        num_partition = indices_V_I_pd[nom_col_partition][indx]
    elif max_min_diff == 3:
        ## max diff
        num_partition = partition_diff(indices_V_I_pd, nom_col_partition, index, 1)
    elif max_min_diff == 4:
        ## min diff
        num_partition = partition_diff(indices_V_I_pd, nom_col_partition, index, 0)

    return num_partition