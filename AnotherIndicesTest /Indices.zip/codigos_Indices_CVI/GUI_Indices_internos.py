'''
Interfaz Gráfica y funciones para la extracción de los indices de validacion internos.
'''

from calendar import leapdays
from cgitb import text
from operator import ne
from turtle import width
from indices_Internos_R import *
from tkinter import *
from tkinter.filedialog import askdirectory
from tkinter.ttk import Progressbar
from tkinter import messagebox
from multiprocessing import Process, Queue, Event, freeze_support
from queue import Empty 
import os
import glob


salida = Queue()
param = Queue() 
avance = Queue()
malas = Queue()
fin_proc = Event()
leer_excel = Event()
leer_excel.set()
procesos = []
mensajes = []
opc_ind = []


#---------------------------------------Funciones de la Interfaz Gráfica-----------------------------------------------#

def admin_procesos_esp(avance, param, salida, procesos, mensajes, fin_proc):
    '''

    Esta función ejecuta secuencialmente los algoritmos de procesamiento y se encarga de que puedan comunicarse entre
    ellos

    :param avance: recibe un Queue para indicar a la barra de progreso el avance del procedimiento
    :param param: recibe un Queue con parámetros necesarios para el siguiente proceso
    :param salida: recibe un Queue que guarda la salida del proceso
    :param procesos: recibe una lista con los procesos que van a ejecutarse (los algoritmos)
    :param mensajes: recibe una lista con cadenas de caracteres que describen cada paso del procesamiento
    :param fin_proc: recibe un Event que indica si el proceso actual terminó
    :return: retorna None
    '''

    if fin_proc.is_set():

        p_actual, valor = avance.get()
        
        p_actual += 1
        if p_actual == 1:
            global carpetas
            carpetas = salida.get(0)

            msj_ad = " 1/1"
            if len(carpetas) > 1:
                msj_ad = " 1/" + str(len(carpetas))

            si_matlab, grab_ruido_fuerte,  rango_init, rango_end, extension = param.get(0)
            param.put((si_matlab, grab_ruido_fuerte, rango_init, rango_end, extension))


            grabaciones = glob.glob(carpetas[0] + '/*' + extension)
            salida.put(grabaciones)
            procesos[p_actual].start()
            fin_proc.clear()
            prog_bar.stop()
            prog_bar["mode"] = "determinate"
            prog_bar["value"] = 0
            prog_bar["maximum"] = len(grabaciones)
            prog_cont["text"] = mensajes[p_actual] + msj_ad
        else:
            prog_bar.stop()
            prog_cont["text"] = "Progreso"
            cor_bot["state"] = "normal"
            mensaje_error("Indices internos guardados correctamente")
            procesos.clear()
            mensajes.clear()
            fin_proc.clear()
            return

    else:

        try:
            p_actual, valor = avance.get(0)
            prog_bar["value"] = valor

        except Empty:
            pass

    ven_pri.after(100, lambda: admin_procesos_esp(avance, param, salida, procesos, mensajes, fin_proc))



def ejecutar_programa(avance, param, salida, fin_proc, procesos, mensajes):

    '''

    Esta función se ejecuta cuando se inicia el procesamiento. Crea los procesos y llama admin_procesos para que regule
    el funcionamiento de los algoritmos.

    :param avance: recibe un Queue para indicar a la barra de progreso el avance del procedimiento
    :param param: recibe un Queue con parámetros necesarios para el siguiente proceso
    :param salida: recibe un Queue que guarda la salida del proceso
    :param fin_proc: recibe un Event que indica si el proceso actual terminó
    :param procesos: recibe una lista con los procesos que van a ejecutarse (los algoritmos)
    :param mensajes: recibe una lista con cadenas de caracteres que describen cada paso del procesamiento
    :return: None
    '''

    indices_internos_teso = 1

    cor_bot["state"] = "disabled"                  
    carpeta_grabaciones = ruta_entry.get()
    extension = '.xlsx'
 
    rango_init_str = rango_init_entry.get()
    rango_end_str = rango_end_entry.get()
    grab_ruido_fuerte = bool(ruido_fuerte.get())
    carpeta_salida = sal_entry.get()
    si_matlab = bool(not sub_var.get())  

    param.put((si_matlab,grab_ruido_fuerte, carpeta_grabaciones, extension, rango_init_str, rango_end_str,carpeta_salida))

    nproc = 0

    val_proc =  Process(target=validar_entradas, args=(avance, param, salida, nproc, fin_proc))
    val_proc.start()
    procesos.append(val_proc)
    prog_cont["text"] = "Verificando entradas"
    mensajes.append("Verificando entradas")
    prog_bar.start()
    nproc += 1

    
    if indices_internos_teso:
        indices_internos_v = select_index()
        fecha_proc = Process(target=calcular_CVI, args=(avance, param, salida, nproc, fin_proc, carpeta_salida, indices_internos_v))
        procesos.append(fecha_proc)
        mensajes.append("Corriendo algoritmo indices de validacion internos...")
        admin_procesos_esp(avance, param, salida, procesos, mensajes, fin_proc) 



def escoger_carpeta(boton):

    '''

    Esta función es invocada cuando se quiere seleccionar una carpeta

    :param boton: Indica el botón que llamó la función (puede ser el botón de la carpeta de entrada o la carpeta de salida
    :return: None
    '''

    ruta = askdirectory()

    if boton == buscar_bot:
        ruta_entry.delete(0, END)
        ruta_entry.insert(0, ruta)

    elif boton == buscars_bot:
        sal_entry.delete(0, END)
        sal_entry.insert(0, ruta)

def mensaje_error(mensaje):

    '''
    Esta función es invocada cuando se presenta un error en el programa. Muestra una ventana con el mensaje de error

    :param mensaje: Str con el mensaje de error a mostrar
    :return: None
    '''

    error_ven = Tk()
    error_ven.withdraw()
    messagebox.showinfo("Aviso", mensaje)
    error_ven.destroy()

def salir(procesos):

    '''

    Esta función es invocada cuando el programa es cerrado por el usuario.

    :param procesos: recibe una lista con los procesos
    :return: None
    '''

    for process in procesos:
        if process.is_alive():
            process.terminate()
    ven_pri.destroy()

def validar_entradas(avance, param, salida, cod_proc, fin_proc):

    '''
    Esta función verifica que los valores ingresados en la interfaz sean correctos

    :param avance: recibe un Queue para indicar a la barra de progreso el avance del procedimiento
    :param param: recibe un Queue con parámetros necesarios para el siguiente proceso
    :param salida: recibe un Queue que guarda la salida del proceso
    :param cod_proc: recibe un entero con el código del proceso
    :param fin_proc: recibe un Event que indica si el proceso actual terminó
    :return: retorna None
    '''

    si_matlab, grab_ruido_fuerte, carpeta_grabaciones, extension, rango_init_str, rango_end_str, carpeta_salida = param.get(0)

   
    grabaciones = glob.glob(carpeta_grabaciones + '/*' + extension)
    if len(grabaciones) == 0:
        mensaje_error("No se encontraron archivos con extencion .xlsx")
        fin_proc.set()
        avance.put((-1, None))
        return
    carpetas = [carpeta_grabaciones]


    if not (rango_init_str+ rango_end_str).isnumeric():
        mensaje_error("Ingrese numero de particiones en numeros")
        fin_proc.set()
        avance.put((-1, None))
        return

    rango_init =   int(rango_init_str)
    rango_end =   int(rango_end_str)

    if rango_init > rango_end:
        mensaje_error("El rango de particiones inicial debe ser mayor al rango final")
        fin_proc.set()
        avance.put((-1, None))
        return

    if rango_init < 2:
        mensaje_error("El rango de particiones inicial debe ser mayor a 2")
        fin_proc.set()
        avance.put((-1, None))
        return

    if not os.path.isdir(carpeta_salida):
        mensaje_error("Ingrese un directorio de salida válido")
        fin_proc.set()
        avance.put((-1, None))
        return


    salida.put(carpetas)
    param.put((si_matlab, grab_ruido_fuerte, rango_init, rango_end, extension))
    fin_proc.set()
    avance.put((cod_proc, None))

def select_index():
    '''
    Esta función selecciona los indices de validacion internos que el usuario desea hallar
    '''
    index=[]
    if (B_H.get()==1):
        index.append('B_H')
    if (B_R.get()==1):
        index.append('B_R')
    if (C.get()==1):
        index.append('C')
    if (CH.get()==1):
        index.append('CH')
    if (DB.get()==1):
        index.append('DB')
    if (D_R.get()==1):
        index.append('D_R')
    if (DI.get()==1):
        index.append('DI')
    if (gamma.get()==1):
        index.append('gamma')
    if (G_mas.get()==1):
        index.append('G_mas')
    if (K_D.get()==1):
        index.append('K_D')
    if (Log_D_R.get()==1):
        index.append('Log_D_R')
    if (Log_B_W.get()==1):
        index.append('Log_B_W')
    if (M_R.get()==1):
        index.append('M_R')
    if (PBM.get()==1):
        index.append('PBM')
    if (P_B.get()==1):
        index.append('P_B')
    if (R_L.get()==1):
        index.append('R_L')
    if (R_T.get()==1):
        index.append('R_T')
    if (S_S.get()==1):
        index.append('S_S')
    if (SD.get()==1):
        index.append('SD')
    if (S_Dbw.get()==1):
        index.append('S_Dbw')
    if (Si.get()==1):
        index.append('Si')
    if (T_W.get()==1):
        index.append('T_W')
    if (T_WiB.get()==1):
        index.append('T_WiB')
    if (W_G.get()==1):
        index.append('W_G')
    if (XB.get()==1):
        index.append('XB')
    if ((PC.get()==1) & (sub_var.get()==0)):
        index.append('PC')
    if ((CE.get()==1) & (sub_var.get()==0)):
        index.append('CE')
    if ((G_str.get()==1) & (sub_var.get()==0)):
        index.append('G_str')
    if ((G_rex.get()==1) & (sub_var.get()==0)):
        index.append('G_rex')
    if (Conn.get()==1):
        index.append('Conn')
    if (CVNN.get()==1):
        index.append('CVNN')
    if ((ICC.get()==1) & (sub_var.get()==0)):
        index.append('ICC')
    if ((CV.get()==1) & (sub_var.get()==0)):
        index.append('CV')
    if (SSDD.get()==1):
        index.append('SSDD')
    if ((LCCV.get()==1) & (sub_var.get()==0)):
        index.append('LCCV')
    if (CSBM.get()==1):
        index.append('CSBM')
    if (WGLI.get()==1):
        index.append('WGLI')
    if ((MPC.get()==1) & (sub_var.get()==0)):
        index.append('MPC')
    if ((PBMF.get()==1) & (sub_var.get()==0)):
        index.append('PBMF')
    if ((MPE.get()==1) & (sub_var.get()==0)):
        index.append('MPE')
    if (CO.get()==1):
        index.append('CO')
    if ((DCVI.get()==1) & (sub_var.get()==0)):
        index.append('DCVI')
    if (DI_nm.get()==1):
        index.append('DI_nm')

    if (todos.get()==1):
        if sub_var.get()==1:
            index=["B_H", "B_R", "C", "CH", "DB", "D_R", "DI", "gamma", "G_mas", "K_D", "Log_D_R", "Log_B_W", "M_R",
                        "PBM", "P_B", "R_L", "R_T", "S_S","SD","S_Dbw", "Si", "T_W", "T_WiB", "W_G", "XB", "Conn",
                        "CVNN", "SSDD", "CSBM", "WGLI", "CO", "DI_nm"]
        else:
            index=["B_H", "B_R", "C", "CH", "DB", "D_R", "DI", "gamma", "G_mas", "K_D", "Log_D_R", "Log_B_W", "M_R",
                        "PBM", "P_B", "R_L", "R_T", "S_S","SD","S_Dbw", "Si", "T_W", "T_WiB", "W_G", "XB", "PC", "CE", "G_str", "G_rex", "Conn",
                        "CVNN", "ICC", "CV", "SSDD", "LCCV", "CSBM", "WGLI", "MPC", "PBMF", "MPE", "CO", "DCVI", "DI_nm"]

        return(index)
        
    else:
        return(index)

def cambio_sin_matlab(*args):
    '''

    Esta función activa o desactiva los indices de valiadcion internos que se pueden seleccionar dependiendo si el usuario tiene matlab

    :param args: Recibe unos argumentos por defecto de la interfaz
    :return: retorna None
    '''

    if sub_var.get() == 1:
        PC_check['state'] = "disabled"
        CE_check['state'] = "disabled"
        G_str_check['state'] = "disabled"
        G_rex_check['state'] = "disabled"
        ICC_check['state'] = "disabled"
        CE_check['state'] = "disabled"
        CV_check['state'] = "disabled"
        LCCV_check['state'] = "disabled"
        DCVI_check['state'] = "disabled"
        MPC_check['state'] = "disabled"
        PBMF_check['state'] = "disabled"
        MPE_check['state'] = "disabled"
    
    elif sub_var.get() == 0:
        PC_check['state'] = "normal"
        CE_check['state'] = "normal"
        G_str_check['state'] = "normal"
        G_rex_check['state'] = "normal"
        ICC_check['state'] = "normal"
        CE_check['state'] = "normal"
        CV_check['state'] = "normal"
        LCCV_check['state'] = "normal"
        DCVI_check['state'] = "normal"
        MPC_check['state'] = "normal"
        PBMF_check['state'] = "normal"
        MPE_check['state'] = "normal"

#------------------------------------- Fin Funciones de la Interfaz Gráfica -------------------------------------------#

# --------------------------------------------- Interfaz Gráfica ------------------------------------------------------#

if __name__ == '__main__': #Se utiliza este if para poder usar varios procesos. (Son necesarios varios procesos para actualizar la barra de progreso)

    freeze_support() #Para correr el programa sin problemas como ejecutable

    ANCHO = 700
    ALTO = 540
    PAD = 7

    # Ventana principal
    ven_pri = Tk()
    ven_pri.geometry(str(ANCHO) + 'x' + str(ALTO))
    ven_pri.title("Índices de validación internos")
    ven_pri.resizable(width=False, height=False)

    # Frame para selección de carpeta
    carp_cont = LabelFrame(ven_pri, text=" Carpeta con base de datos de los índices acústicos")
    carp_cont.pack(fill=X, padx=PAD, pady=PAD)
    ruta_entry = Entry(carp_cont, width=45)
    ruta_entry.pack(side=LEFT)
    sub_var = IntVar()
    #sub_check = Checkbutton(carp_cont, text="Contiene subcarpetas", justify=CENTER, variable=sub_var, state="normal")
    sub_check = Checkbutton(carp_cont, text="SIN MATLAB", justify=CENTER, variable=sub_var, state="normal")
    sub_check.pack(side=LEFT)
    sub_var.trace('w', cambio_sin_matlab)
    buscar_bot = Button(carp_cont, text="Buscar...", command=lambda: escoger_carpeta(buscar_bot))
    buscar_bot.pack(expand=True)

    

    # Frame Configuración que contiene otros frames
    conf_cont = LabelFrame(ven_pri, text=" Configuración de Particiones ")
    conf_cont.pack(fill=X, padx=PAD, pady=PAD)
                                                                                                                                                     
    
    #Frame para configuración de índices                                                       
    ind_cont = LabelFrame(conf_cont, text=" índices internos")                                     
    ind_cont.pack(side=LEFT, padx=PAD, pady=PAD)                                                 
    ruido_fuerte = IntVar()                                                                             
    todo_check = Checkbutton(ind_cont, text="Calcular índices internos sin ruido fuerte                                       ", justify=LEFT, \
                                 variable=ruido_fuerte, state="normal")                                 
    todo_check.pack() 


    # Frame para configuración del rango de particiones
    rango_par_cont = LabelFrame(conf_cont, text=" Rango Particiones ")
    rango_par_cont.pack(side=LEFT, padx=PAD, pady=PAD)
    rango_init_lab = Label(rango_par_cont, text="inicio:   ")
    rango_init_lab.grid()
    rango_init_entry = Entry(rango_par_cont, width=10, justify=CENTER)
    rango_init_entry.insert(0, "2")
    rango_init_entry.grid(row=0, column=1)
    rango_end_lab = Label(rango_par_cont, text="final:   ")
    rango_end_lab.grid(row=1, column=0)
    rango_end_entry = Entry(rango_par_cont, width=10, justify=CENTER)
    rango_end_entry.insert(0, "6")
    rango_end_entry.grid(row=1, column=1)


    #Frame para seleccionar indices________________________
    select_cont = LabelFrame(ven_pri, text=" Seleccionar indices internos")
    select_cont.pack(fill=X, padx=PAD, pady=PAD)
    
    #frame funcione
    c_cont = LabelFrame(select_cont)
    c_cont.pack(padx=PAD, pady=PAD, side=LEFT)
    B_H = IntVar()
    B_R = IntVar()
    C = IntVar()
    CH = IntVar()
    DB = IntVar()
    D_R = IntVar()
    B_H_check= Checkbutton(c_cont, text="B_H   ", justify=LEFT, variable=B_H, state="normal")
    B_H_check.pack()
    B_R_check= Checkbutton(c_cont, text="B_R    ", justify=LEFT, variable=B_R, state="normal")
    B_R_check.pack()
    C_check= Checkbutton(c_cont, text="C        ", justify=LEFT, variable=C, state="normal")
    C_check.pack()
    CH_check= Checkbutton(c_cont, text="CH     ", justify=LEFT, variable=CH, state="normal")
    CH_check.pack()     
    DB_check= Checkbutton(c_cont, text="DB     ", justify=LEFT,variable=DB, state="normal")
    DB_check.pack()
    D_R_check= Checkbutton(c_cont, text="D_R   ", justify=LEFT, variable=D_R, state="normal")
    D_R_check.pack()

    c_cont1 = LabelFrame(select_cont)
    c_cont1.pack(padx=PAD, pady=PAD, side=LEFT)
    DI = IntVar()
    DI_nm = IntVar()
    gamma = IntVar()
    G_mas = IntVar()
    K_D = IntVar()
    Log_D_R = IntVar()
    DI_check= Checkbutton(c_cont1, text="Dunn         ", justify=LEFT, variable=DI, state="normal")
    DI_check.pack()
    DI_nm_check= Checkbutton(c_cont1, text="GDI_nm   ", justify=RIGHT, variable=DI_nm, state="normal")
    DI_nm_check.pack()
    gamma_check= Checkbutton(c_cont1, text="Gamma  ", justify=RIGHT, variable=gamma, state="normal")
    gamma_check.pack()
    G_mas_check= Checkbutton(c_cont1, text="G+          ", justify=RIGHT, variable=G_mas, state="normal")
    G_mas_check.pack()    
    K_D_check= Checkbutton(c_cont1, text="K_D         ", justify=RIGHT,variable=K_D, state="normal")
    K_D_check.pack()
    Log_D_R_check= Checkbutton(c_cont1, text="Log_D_R ", justify=RIGHT, variable=Log_D_R, state="normal")
    Log_D_R_check.pack()

    c_cont2 = LabelFrame(select_cont)
    c_cont2.pack(padx=PAD, pady=PAD, side=LEFT)
    Log_B_W = IntVar()
    M_R = IntVar()
    PBM = IntVar()
    P_B = IntVar()
    R_L = IntVar()
    R_T = IntVar()
    Log_B_W_check= Checkbutton(c_cont2, text="Log_B_W", justify=RIGHT, variable=Log_B_W, state="normal")
    Log_B_W_check.pack()
    M_R_check= Checkbutton(c_cont2, text="M_R        ", justify=RIGHT, variable=M_R, state="normal")
    M_R_check.pack()
    PBM_check= Checkbutton(c_cont2, text="PBM        ", justify=RIGHT, variable=PBM, state="normal")
    PBM_check.pack()
    P_B_check= Checkbutton(c_cont2, text="P_B         ", justify=RIGHT, variable=P_B, state="normal",)
    P_B_check.pack()
    R_L_check= Checkbutton(c_cont2, text="R_L         ", justify=RIGHT,variable=R_L, state="normal")
    R_L_check.pack()
    R_T_check= Checkbutton(c_cont2, text="R_T         ", justify=RIGHT, variable=R_T, state="normal")
    R_T_check.pack()

    c_cont3 = LabelFrame(select_cont)
    c_cont3.pack(padx=PAD, pady=PAD, side=LEFT)
    S_S = IntVar()
    SD = IntVar()
    S_Dbw = IntVar()
    Si = IntVar()
    T_W = IntVar()
    T_WiB = IntVar()
    S_S_check= Checkbutton(c_cont3, text="S_S     ", justify=RIGHT, variable=S_S, state="normal",)
    S_S_check.pack()
    SD_check= Checkbutton(c_cont3, text="SD      ", justify=RIGHT, variable=SD, state="normal",)
    SD_check.pack()
    S_Dbw_check= Checkbutton(c_cont3, text="S_Dbw", justify=RIGHT, variable=S_Dbw, state="normal")
    S_Dbw_check.pack()
    Si_check= Checkbutton(c_cont3, text="Si        ", justify=RIGHT, variable=Si, state="normal")
    Si_check.pack()
    T_W_check= Checkbutton(c_cont3, text="T_W    ", justify=RIGHT, variable=T_W, state="normal")
    T_W_check.pack()
    T_WiB_check= Checkbutton(c_cont3, text="T_WiB", justify=RIGHT, variable=T_WiB, state="normal",)
    T_WiB_check.pack()

    c_cont4 = LabelFrame(select_cont)
    c_cont4.pack(padx=PAD, pady=PAD, side=LEFT)
    W_G = IntVar()
    XB = IntVar()
    PC = IntVar()
    CE = IntVar()
    G_str = IntVar()
    G_rex = IntVar()
    W_G_check= Checkbutton(c_cont4, text="W_G  ", justify=RIGHT, variable=W_G, state="normal",)
    W_G_check.pack()
    XB_check= Checkbutton(c_cont4, text="XB     ", justify=RIGHT, variable=XB, state="normal")
    XB_check.pack()
    PC_check= Checkbutton(c_cont4, text="PC     ", justify=RIGHT, variable=PC, state="normal")
    PC_check.pack()
    CE_check= Checkbutton(c_cont4, text="CE     ", justify=RIGHT, variable=CE, state="normal")
    CE_check.pack()
    G_str_check= Checkbutton(c_cont4, text="G_str ", justify=RIGHT, variable=G_str, state="normal",)
    G_str_check.pack()
    G_rex_check= Checkbutton(c_cont4, text="G_rex", justify=RIGHT, variable=G_rex, state="normal",)
    G_rex_check.pack()

    c_cont5 = LabelFrame(select_cont)
    c_cont5.pack(padx=PAD, pady=PAD, side=LEFT)
    Conn = IntVar()
    CVNN = IntVar()
    ICC = IntVar()
    CV = IntVar()
    SSDD = IntVar()
    LCCV = IntVar()
    Conn_check= Checkbutton(c_cont5, text="Conn  ", justify=RIGHT, variable=Conn, state="normal")
    Conn_check.pack()
    CVNN_check= Checkbutton(c_cont5, text="CVNN", justify=RIGHT, variable=CVNN, state="normal")
    CVNN_check.pack()
    ICC_check= Checkbutton(c_cont5, text="ICC     ", justify=RIGHT, variable=ICC, state="normal")
    ICC_check.pack()
    CV_check= Checkbutton(c_cont5, text="CV      ", justify=RIGHT, variable=CV, state="normal",)
    CV_check.pack()
    SSDD_check= Checkbutton(c_cont5, text="SSDD ", justify=RIGHT, variable=SSDD, state="normal",)
    SSDD_check.pack()
    LCCV_check= Checkbutton(c_cont5, text="LCCV", justify=RIGHT, variable=LCCV, state="normal")
    LCCV_check.pack()


    c_cont6 = LabelFrame(select_cont)
    c_cont6.pack(padx=PAD, pady=PAD, side=LEFT)
    CSBM = IntVar()
    WGLI = IntVar()
    MPC = IntVar()
    PBMF = IntVar()
    MPE = IntVar()
    CO = IntVar()
    CSBM_check= Checkbutton(c_cont6, text="CSBM", justify=RIGHT, variable=CSBM, state="normal")
    CSBM_check.pack()
    WGLI_check= Checkbutton(c_cont6, text="WGLI ", justify=RIGHT, variable=WGLI, state="normal")
    WGLI_check.pack()
    MPC_check= Checkbutton(c_cont6, text="MPC ", justify=RIGHT, variable=MPC, state="normal",)
    MPC_check.pack()
    PBMF_check= Checkbutton(c_cont6, text="PBMF", justify=RIGHT, variable=PBMF, state="normal",)
    PBMF_check.pack()
    MPE_check= Checkbutton(c_cont6, text="MPE ", justify=RIGHT, variable=MPE, state="normal")
    MPE_check.pack()
    CO_check= Checkbutton(c_cont6, text="CO   ", justify=RIGHT, variable=CO, state="normal")
    CO_check.pack()

    c_cont7 = LabelFrame(select_cont)
    c_cont7.pack(padx=PAD, pady=PAD, side=LEFT)
    DCVI = IntVar()
    DCVI_check= Checkbutton(c_cont7, text="DCVI ", justify=RIGHT, variable=DCVI, state="normal")
    DCVI_check.pack()    
    espacio_lab1 = Label(c_cont7)  
    espacio_lab1.pack()  
    espacio_lab2 = Label(c_cont7)  
    espacio_lab2.pack()  
    espacio_lab3 = Label(c_cont7)  
    espacio_lab3.pack() 
    espacio_lab4 = Label(c_cont7)  
    espacio_lab4.pack() 
    todos = BooleanVar()
    todos_check= Checkbutton(c_cont7, text="Todos", justify=RIGHT, variable=todos, state="normal")
    todos_check.pack()
    btnselect= Button(c_cont7, text="Seleccionar", command=select_index)
    btnselect.pack()
    indices_internos= select_index()

    
    #Frame ver
    lblindex=Label(select_cont)
    lblindex.pack()
    
    # Frame para carpeta de salida
    scarp_cont = LabelFrame(ven_pri, text=" Carpeta de Salida ")
    scarp_cont.pack(fill=X, side=TOP, padx=PAD, pady=PAD)
    sal_entry = Entry(scarp_cont, width=65)
    sal_entry.pack(side=LEFT)
    buscars_bot = Button(scarp_cont, text="Buscar...", command=lambda: escoger_carpeta(buscars_bot))
    buscars_bot.pack(expand=True)

    
    # Parámetros de Salida
    sal_cont = LabelFrame(ven_pri)
    sal_cont.pack(fill=X, padx=PAD, pady=PAD)
    espacio_lab_FIN = Label(sal_cont, text="                                                                                                                                                                      ")  
    espacio_lab_FIN.pack(side=LEFT) 
    cor_bot = Button(sal_cont, text="Iniciar", width=30,
                     command= lambda : ejecutar_programa(avance, param, salida, fin_proc, procesos, mensajes))
    cor_bot.pack(expand=True)
    

    # Label de Progreso
    prog_cont = LabelFrame(ven_pri, text="Progreso")
    prog_cont.pack(fill=X, padx=PAD, pady=PAD, ipady=PAD)
    prog_bar = Progressbar(prog_cont, orient="horizontal", mode="indeterminate")
    prog_bar.pack(fill=X, padx=PAD)
    ven_pri.protocol("WM_DELETE_WINDOW", lambda : salir(procesos))
    ven_pri.mainloop()

#--------------------------------------------- Fin Interfaz Gráfica ---------------------------------------------------#
