from tokenize import Double
import numpy as np  
import pandas as pd
import rpy2.robjects as robj
from rpy2.robjects.packages import importr
from sklearn.mixture import GaussianMixture
from indices_internos_python import *
from opt_partition_CVI import *

def indices_R(pd_df, array_W_pd_trans, array_datos_pd, array_datos_pd_mat, cluster, clusterV, Vgm_mat, xr, xr_W, xr_Vgm, clustervec, index,clusterCrit1, fcvalid1, resulIndicesmat):
    '''
    pd_df: conjunto de datos en dataframe (objetos por variables)
    array_W_pd_trans: grados de pertenecia de cada objeto a los diferentes cluster
    array_datos_pd: conjunto de datos en array (objetos por variables)
    array_datos_pd_mat: conjunto de datos en array tipo matlab (objetos por variables)
    cluster: La etiqueta del clúster correspondiente a cada fila
    clusterV: Los centroides encontrados por el algoritmo GMM
    Vgm_mat: Los centroides encontrados por el algoritmo GMM tipo matlab
    xr: conjunto de datos tipo matrix para R (objetos por variables)
    xr_W: grados de pertenecia de cada objeto a los diferentes cluster para R
    xr_Vgm: Los centroides encontrados por el algoritmo GMM tipo matrix para R
    clustervec: Los centroides encontrados por el algoritmo GMM tipo vectorial para R
    index: nombre del indice de validacion interno analizar
    clusterCrit1: libreria de R
    fcvalid1: libreria de R
    resulIndicesmat: funcion de matlab para hallar algunos indices de validacion internos
    '''
    
    switch =  {
        'B_H': lambda: clusterCrit1.intCriteria(xr,clustervec,"Ball_Hall"),
        'B_R': lambda: clusterCrit1.intCriteria(xr,clustervec,"Banfeld_Raftery"),
        'C': lambda: clusterCrit1.intCriteria(xr,clustervec,"C_index"),
        'CH': lambda: clusterCrit1.intCriteria(xr,clustervec,"Calinski_Harabasz"),
        'DB': lambda: clusterCrit1.intCriteria(xr,clustervec,"Davies_Bouldin"),
        'D_R': lambda: clusterCrit1.intCriteria(xr,clustervec,"Det_Ratio"),
        'DI': lambda: clusterCrit1.intCriteria(xr,clustervec,"Dunn"),
        'gamma': lambda: clusterCrit1.intCriteria(xr,clustervec,"Gamma"),
        'G_mas': lambda: clusterCrit1.intCriteria(xr,clustervec,"G_plus"),
        'GDI11': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI11"),
        'GDI12': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI12"),
        'GDI13': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI13"),
        'GDI21': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI21"),
        'GDI22': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI22"),
        'GDI23': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI23"),
        'GDI31': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI31"),
        'GDI32': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI32"),
        'GDI33': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI33"),
        'GDI41': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI41"),
        'GDI42': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI42"),
        'GDI43': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI43"),
        'GDI51': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI51"),
        'GDI52': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI52"),
        'GDI53': lambda: clusterCrit1.intCriteria(xr,clustervec,"GDI53"),
        'K_D': lambda: clusterCrit1.intCriteria(xr,clustervec,"Ksq_DetW"),
        'Log_D_R': lambda: clusterCrit1.intCriteria(xr,clustervec,"Log_Det_Ratio"),
        'Log_B_W': lambda: clusterCrit1.intCriteria(xr,clustervec,"Log_SS_Ratio"),
        'M_R': lambda: clusterCrit1.intCriteria(xr,clustervec,"McClain_Rao"),
        'PBM': lambda: clusterCrit1.intCriteria(xr,clustervec,"PBM"),
        'P_B': lambda: clusterCrit1.intCriteria(xr,clustervec,"Point_Biserial"),
        'R_T': lambda: clusterCrit1.intCriteria(xr,clustervec,"Ray_Turi"),
        'R_L': lambda: clusterCrit1.intCriteria(xr,clustervec,"Ratkowsky_Lance"),
        'S_S': lambda: clusterCrit1.intCriteria(xr,clustervec,"Scott_Symons"),
        'S_Dbw': lambda: clusterCrit1.intCriteria(xr,clustervec,"S_Dbw"),
        'Si': lambda: clusterCrit1.intCriteria(xr,clustervec,"Silhouette"),
        'T_W': lambda: clusterCrit1.intCriteria(xr,clustervec,"Trace_W"),
        'T_WiB': lambda: clusterCrit1.intCriteria(xr,clustervec,"Trace_WiB"),
        'W_G': lambda: clusterCrit1.intCriteria(xr,clustervec,"Wemmert_Gancarski"),
        'XB': lambda: clusterCrit1.intCriteria(xr,clustervec,"Xie_Beni"),
        'PC': lambda: np.array([[resulIndice1(array_datos_pd_mat, cluster, Vgm_mat, 1, resulIndicesmat)]]),
        'CE': lambda: np.array([[resulIndice1(array_datos_pd_mat, cluster, Vgm_mat, 2, resulIndicesmat)]]),
        'G_str': lambda: np.array([[resulIndice1(array_datos_pd_mat, cluster, Vgm_mat, 3, resulIndicesmat)]]),
        'G_rex': lambda: np.array([[resulIndice1(array_datos_pd_mat, cluster, Vgm_mat, 4, resulIndicesmat)]]),
        'ICC': lambda: np.array([icc1(pd_df, array_W_pd_trans, clusterV)]),
        'CV': lambda: np.array([[resulIndice1(array_datos_pd_mat, cluster, Vgm_mat, 5, resulIndicesmat)]]),
        'SSDD': lambda: np.array([[SSDD_index(array_datos_pd,cluster,5)]]),
        'LCCV': lambda: np.array([[resulIndice1(array_datos_pd_mat, cluster, Vgm_mat, 6, resulIndicesmat)]]),
        'DCVI': lambda: np.array([[resulIndice1(array_datos_pd_mat, cluster, Vgm_mat, 7, resulIndicesmat)]]),
        'MPC': lambda: np.array([fcvalid1.mpc(u=xr_W, m=2.0, tidx="f")]),
        'PBMF': lambda: np.array([fcvalid1.pbm(x=xr, u=xr_W, v=xr_Vgm, m=2.0, tidx="f")]),
        'MPE': lambda: np.array([[MPE1(array_datos_pd_mat, cluster, Vgm_mat, resulIndicesmat)]]),
    }

    return (switch.get(index,  lambda: 'N')())[0][0]


def MPE1(array_datos_pd_mat, clgm, Vgm_mat, resulIndicesmat):
    '''
    array_datos_pd_mat: conjunto de datos en array tipo matlab (objetos por variables)
    clgm: La etiqueta del clúster correspondiente a cada fila
    Vgm_mat: Los centroides encontrados por el algoritmo GMM tipo matlab
    resulIndicesmat: funcion de matlab para hallar algunos indices de validacion internos
    '''
    unique_labels1 = np.unique(clgm)
    k = len(unique_labels1)

    CE_index = resulIndice1(array_datos_pd_mat, clgm, Vgm_mat, 2, resulIndicesmat)
    MPE = (len(clgm)*CE_index)/(len(clgm)-k)

    return MPE


def resulIndice1(array_datos_pd_mat, clgm, Vgm_mat, indexVI, resulIndicesmat):
    import matlab
    unique_labels1 = np.unique(clgm)
    k = len(unique_labels1)

    clgm_aux = clgm.copy()
    for a in range(k):
        per_clase = clgm==unique_labels1[a]
        clgm_aux[per_clase] = a+1
    clgm = clgm_aux

    clgm = matlab.double((clgm.reshape((len(clgm), 1))).tolist())
    indicesmatlat = resulIndicesmat.resulIndices(array_datos_pd_mat, len(Vgm_mat), clgm, Vgm_mat, 0, 0, 0, indexVI)
    return indicesmatlat

def calcular_CVI(avance, param, salida, cod_proc, fin_proc, ruta_salida_inf_CVI, indices_internos):

    si_matlab, grab_ruido_fuerte, rango_init, rango_end, extension = param.get(0)
    param.put((si_matlab, grab_ruido_fuerte, rango_init, rango_end, extension))

    # Se obtienen las rutas de cada excel que contienen la informacion acustica de las grabaciones analizar
    grabaciones = salida.get(0) 

    # indices de validacion internos analizar
    nom_Index = indices_internos
    print(nom_Index)
    
    # Se establece si se hallan los indices que dependen de MATLAB
    if si_matlab:
        import partitionmatrix
        import resulIndicesmatlab
        import matlab

        partition = partitionmatrix.initialize()

        clusterCrit1 = importr('clusterCrit')
        fcvalid1 = importr('fcvalid')
        
        resulIndicesmat = resulIndicesmatlab.initialize()
    else:
        clusterCrit1 = importr('clusterCrit')
        fcvalid1 = 1
        resulIndicesmat=1

    # informacion de los nombres pertenecientes al indices "Generalized Dunn"
    GDI_nm=["GDI11", "GDI12", "GDI13", "GDI21", "GDI22", "GDI23", "GDI31", "GDI32", "GDI33", "GDI41", "GDI42", "GDI43", "GDI51", "GDI52", "GDI53"]
    N_particion=["N_particiones"]

    total_clusters = rango_end - rango_init + 1

    #Jaguas
    #indices_escogidos=['ACIft','ADI','ACItf','BETA','P','M','NP','MID','BNF','MD','FM','SF','RMS','CF','SC','SB','Tonnets','SNR','ADIm11']

    #Bolivar
    #indices_escogidos=['ADI','ACItf','BETA','P','M','NP','MID','BNF','MD','FM','SF', 'RMS','CF','SC','SB','Tonnets','SNR','ADIm8']

    #Guajira
    #indices_escogidos=['ADI','ACItf','BETA','P','M','NP','MID','BNF','MD','SF','RMS','CF','SC','SB','Tonnets','SNR','ADIm8']

    for variable in range(len(grabaciones)):
        # variable del indice CVNN
        COM1 = []
        SEP1 = []
        unique_labels_CVNN = []

        # variables del indice SD
        scat1 = []
        dis1 = []
        unique_labels_SD = []

        indices_V_I = []
        etiquetas_array = []

        #pd_df=pd.read_excel(grabaciones[variable])
        df1=pd.read_excel(grabaciones[variable])
        if grab_ruido_fuerte:
            if 'lluvia' in df1.columns:
                pd_df1=df1[(df1['lluvia']==0)].copy()
                pd_df = pd_df1.drop(['lluvia'], axis=1)
                #pd_df=pd_df1[indices_escogidos].copy()
            else:
                pd_df=df1.copy()
                #pd_df=df1[indices_escogidos].copy()
                #print(pd_df)
        else:
            pd_df=df1.copy()
            #pd_df=df1[indices_escogidos].copy()
            #print(pd_df)

        for num_cluster in range(rango_init, rango_end + 1):
            print("NUEMRO DE CLUSTERS: " + str(num_cluster) + "  EXCEL #" + str(variable))

            avan_num_cluster = num_cluster - rango_init + 1

            GM = GaussianMixture(n_components=num_cluster, random_state=0).fit(pd_df)
            cluster=GM.predict(pd_df)

            clusterV = GM.means_
            Vgm_pd = pd.DataFrame(clusterV)

            array_datos_pd=pd_df.to_numpy()

            if si_matlab:
                Vgm_mat = matlab.double(clusterV.tolist())

                array_datos_pd_mat = matlab.double(array_datos_pd.tolist())

                W = partition.partition_matrix(array_datos_pd_mat,Vgm_mat,num_cluster,2.0)
                W = pd.DataFrame(W)
                array_W_pd_trans=(W.T).to_numpy()

                x=np.array(W)
                nr, nc = x.shape
                xvec = robj.FloatVector(x.transpose().reshape((x.size)))
                xr_W = robj.r.matrix(xvec, nrow=nr, ncol=nc)
            else:
                Vgm_mat=1
                array_datos_pd_mat=1
                array_W_pd_trans=1
                xr_W=1

            x=np.array(pd_df)
            nr, nc = x.shape
            xvec = robj.FloatVector(x.transpose().reshape((x.size)))
            xr = robj.r.matrix(xvec, nrow=nr, ncol=nc)

            clustervec = robj.IntVector(cluster.transpose().reshape((cluster.size)))
            
            x=np.array(Vgm_pd)
            nr, nc = x.shape
            xvec = robj.FloatVector(x.transpose().reshape((x.size)))
            xr_Vgm = robj.r.matrix(xvec, nrow=nr, ncol=nc)


            avance_general = avan_num_cluster/total_clusters
            indices_V_I.append(num_cluster)
            for i in range(len(nom_Index)):
                if (nom_Index[i] != "DI_nm") & (nom_Index[i] != "SD") & (nom_Index[i] != "CVNN"):
                    value_index = indices_R(pd_df, array_W_pd_trans, array_datos_pd, array_datos_pd_mat, cluster, clusterV, Vgm_mat, xr, xr_W, xr_Vgm, clustervec, nom_Index[i], clusterCrit1, fcvalid1, resulIndicesmat)
                    if value_index=='N':
                        value_index = 0
                    indices_V_I.append(value_index)
                elif nom_Index[i] == "SD":
                    scat_aux , dis_aux, unique_labels_aux_SD = SD1(array_datos_pd, cluster)
                    scat1.append(scat_aux)
                    dis1.append(dis_aux)
                    unique_labels_SD.append(unique_labels_aux_SD)
                    indices_V_I.append(0)
                elif nom_Index[i] == "CVNN":
                    COM_aux , SEP_aux, unique_labels_aux_CVNN = CVNN1(array_datos_pd, cluster)
                    COM1.append(COM_aux)
                    SEP1.append(SEP_aux)
                    unique_labels_CVNN.append(unique_labels_aux_CVNN)
                    indices_V_I.append(0)
                elif nom_Index[i] == "DI_nm":
                    for b in range(15):
                        value_index = indices_R(pd_df, array_W_pd_trans, array_datos_pd, array_datos_pd_mat, cluster, clusterV, Vgm_mat,  xr, xr_W, xr_Vgm, clustervec, GDI_nm[b], clusterCrit1, fcvalid1, resulIndicesmat)
                        indices_V_I.append(value_index)
            avance.put((cod_proc, variable + avance_general))

            etiquetas_array.append(cluster)

        # Se organiza la informacion de los indices internos
        if "DI_nm" in nom_Index:
            columns_indexs = N_particion + nom_Index[0:-1] + GDI_nm
            indarray = np.array(indices_V_I)
            indarray = indarray.reshape(total_clusters,len(nom_Index[0:-1]) + len(GDI_nm) + 1)
            indices_V_I_pd = pd.DataFrame(indarray, columns= columns_indexs)
        else:
            columns_indexs = N_particion + nom_Index
            indarray = np.array(indices_V_I)
            indarray = indarray.reshape(total_clusters,len(nom_Index) + 1)
            indices_V_I_pd = pd.DataFrame(indarray, columns= columns_indexs)
        
        if "SD" in nom_Index:
            indices_V_I_pd["SD"] = SD_valid_n1(rango_init, (rango_end + 1), scat1, dis1, unique_labels_SD)

        if "CVNN" in nom_Index:
            indices_V_I_pd["CVNN"] = CVNN_n1(rango_init, (rango_end + 1), COM1, SEP1, unique_labels_CVNN)
        

        # Se le incluye al dataframe las particiones analizadas
        etiquetas_array = np.array(etiquetas_array)
        etiquetas_array = etiquetas_array.reshape(total_clusters, len(pd_df))
        pd_df_aux = pd_df.copy()
        pd_df_aux[indices_V_I_pd[N_particion[0]].tolist()] = etiquetas_array.T
        
        # Se obtienen las particiones recomendadas por los indices de validacion internos
        list_opt_indexs = []
        for id_nom in range(1,len(columns_indexs)):
            if len((indices_V_I_pd[columns_indexs[id_nom]].dropna()).to_list()) >= 1:
                list_opt_indexs.append(opt_partition_index(indices_V_I_pd, columns_indexs[0], columns_indexs[id_nom]))
            else:
                list_opt_indexs.append("Full NaN")

        # se guarda la informacion del analisis de cada excel
        nom_Excel = grabaciones[variable].split('\\')[-1]
        nom_Excel = nom_Excel.split('.')[0] + '_CVI'
        ruta_salida = ruta_salida_inf_CVI + '/' + nom_Excel + '.xlsx'
        print("Excel generado en la ruta")
        print(ruta_salida)

        writer = pd.ExcelWriter(ruta_salida)

        pd_df_aux.to_excel(writer, index_label="N_object", sheet_name="data_partition")

        indices_V_I_pd.to_excel(writer, index_label="Filas", sheet_name="CVI")

        columns_indexs.pop(0)
        list_opt_indexs_aux = np.array(list_opt_indexs)
        list_opt_indexs_aux = list_opt_indexs_aux.reshape(1,len(list_opt_indexs))

        opt_indexs_pd = pd.DataFrame(list_opt_indexs_aux, columns=columns_indexs)
        opt_indexs_pd.to_excel(writer, sheet_name="opt_partition")
        
        writer.close()
 

    fin_proc.set()
    avance.put((cod_proc, 0))
