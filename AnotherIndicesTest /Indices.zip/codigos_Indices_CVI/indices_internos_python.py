'''
Contine los algoritmos que calculan los indices de validacion internos (ICC, CVNN, SD, SSDD) 
'''

from sklearn.metrics.pairwise import euclidean_distances
from numpy import linalg as LA
import math  
import numpy as np
import scipy as sy
from math import pow 
import math
from statistics import mean
from sklearn.neighbors import NearestNeighbors
from scipy.spatial.distance import pdist, squareform

class ICC():
  i=0
  def __init__(self):
        self.x =None
        self.u =None
        #self.ii=None
        self.n=None
        self.c=None
        self.clusterscentroids=[]
        self.clusters_centroids=None
        self.diffarray=[]
        self.summarraySbe=[]


  def fit(self,x,u,cc):
       '''
       x: conjunto de datos en dataframe (objetos por variables)
       u: grados de pertenecia de cada objeto a los diferentes cluster
       cc: centrides de los cluster
       '''
       self.x =x
       self.u =u
       self.n =x.shape[0]
       self.c =u.shape[1]
       self.clusters_centroids=cc
       #self.clusters_centroidsfn()
       return self.iccc()

  def iccc(self): 

        return (self.Sbe()/self.n)*self.Dmin()*(math.sqrt(self.c))

  def m(self):
    #dataset centroid
    #its neccesary that x be a matrix (only works for multivariate case)
        return np.sum(self.x,axis=0)/self.x.shape[0]

  def mei(self,i):
    #This function calculate the partition centroid
    #x is the dataset matrix
    # u is the matrix of fuzzy membership and i is the ith cluster vector
        return np.sum(self.x*self.u[:,self.i][:, np.newaxis],axis=0)/np.sum(self.u[:,i])

  def clusters_centroidsfn(self):
        for i in range(self.u.shape[1]):
              self.clusterscentroids.append(self.mei(i))
        self.clusters_centroids=np.asarray(self.clusterscentroids) 

  def Dmin(self):
   #computes the minimun euclidean distance between all the cluster centers
           
        for i in range(len(self.clusters_centroids)-1):
            self.diffarray.extend(euclidean_distances(self.clusters_centroids[(i+1):,:],self.clusters_centroids[i,:].reshape(1, -1)))
        return min(np.asarray(self.diffarray))
  
  def Sbe(self):
        for i in range(self.clusters_centroids.shape[0]):
              self.summarraySbe.append(sum(self.u[:,i]*LA.norm(self.clusters_centroids[i]-self.m(), 2)))
        return sum(self.summarraySbe)

## Forma de hallar el indice validacion interno ICC
def icc1(pd_df, array_W_pd_trans, clusterV):

    p1 = ICC()
    icc=p1.fit(pd_df, array_W_pd_trans, clusterV)

    return icc

class internalIndex:
    def  __init__(self, num_k, class_iter):
        '''
        num_k: numero de cluster
        class_iter: nombre de las tiquetas en orden
        '''
        self.num_k = num_k
        self.class_iter = class_iter
    
    def euclidean_centroid(self, data,label, label_num = False):
        if label_num == False:
            num_attr = data.shape[1]
            centroid = np.zeros([1, num_attr])
            for attr_id in range(num_attr):
                sum_attr_id = 0
                for i in range(len(data)):
                    sum_attr_id += data[i][attr_id]
                centroid[0][attr_id] = sum_attr_id/len(data)
            return centroid[0]
        else:
            count = 0
            for l in label:
                if l == label_num:
                    count +=1
            length = count
            num_attr = data.shape[1]
            centroid = np.zeros([1, num_attr])
            for attr_id in range(num_attr):
                sum_attr_id = 0
                for i in range(len(data)):
                    if label[i] == label_num:
                        sum_attr_id += data[i][attr_id]
                centroid[0][attr_id] = sum_attr_id/length
            return centroid[0]
    def centroid_list(self, data,label):
        c_list = []
        for index_i in self.class_iter:
            c_list.append(self.euclidean_centroid(data,label,index_i))
        return c_list
        
    def element_of_clustert (self, data, label, cluster_i):
        eoc = []
        for l in range(len(data)):
            if label[l] == cluster_i:
                eoc.append(data[l])
        return np.asarray(eoc)
    
    def distance_from_cluster (self, data, label,  cluster_i, centroid_i):
        eoc = self.element_of_clustert(data, label, cluster_i)
        centroid_i = self.euclidean_centroid(data, label, centroid_i)
        distance = 0
        for i in eoc:
            distance += sy.spatial.distance.euclidean(centroid_i, i)
        return distance
    
    def distance_from_cluster_sqr (self, data, label,  cluster_i, centroid_i):
        eoc = self.element_of_clustert(data, label, cluster_i)
        centroid_i = self.euclidean_centroid(data, label, centroid_i)
        distance = 0
        for i in eoc:
            distance += sy.spatial.distance.sqeuclidean(centroid_i, i)
        return distance
    
    def cluster_stdev(self, data, label, i = False):
        if i == 'all':
            result = 0
            for c in self.class_iter:
                result +=self.cluster_stdev(data, label,c)
            return (np.sqrt(result)) / self.num_k
        if i !=False:
            data = self.element_of_clustert(data, label, i)
        var_vec = np.var(data, 0 )
        var_vec_t = np.transpose(var_vec)
        return np.sqrt(np.dot(var_vec,var_vec_t))
    
    def nn_exclude(self, data, label, data_i ,label_i ,k):
        data_i = [data_i]
        dist_mat = sy.spatial.distance.cdist(data_i, data)[0]
        dist_mat = np.argsort(dist_mat)[1:k+1]
        count = 0
        for i in dist_mat:
            if label_i != i:
                count = count + 1
        return count
        
    
    def CVNN(self, data, label ):
        #Need COM and SEP
        '''
        data: conjunto de datos en dataframe (objetos por variables)
        label: La etiqueta del clúster correspondiente a cada fila
        '''
        k = 10
        COM = 0
        SEP = []
        for index_i in self.class_iter:
            temp_sep = 0
            eoc  = self.element_of_clustert(data, label, index_i)
            n= len(eoc)
            if n !=1:
                COM = COM + (sum(sy.spatial.distance.pdist(eoc,'euclidean')) * 2 / (n*(n-1)))
            for e in eoc:
                q_index_e = self.nn_exclude(data, label, e, index_i, k )
                temp_sep = temp_sep +(q_index_e / k)
            SEP.append(temp_sep)
        SEP = max(SEP)
        return COM , SEP
    
    def CVNN_n(self, COM, SEP, rango_init):
        index = self.num_k - rango_init
        return COM[index] / max(COM) + SEP[index] / max(SEP)
    
    def Scat(self, data, label):
        result = 0
        for i in self.class_iter:
            result += self.cluster_stdev(data,label,i)
        return (result / ((self.num_k - 1)  * self.cluster_stdev(data,label)))

    def SD_valid (self, data, label):
        '''
        data: conjunto de datos en dataframe (objetos por variables)
        label: La etiqueta del clúster correspondiente a cada fila
        '''
        scat =self.Scat(data, label)
        centroid_list = []
        for index_i in self.class_iter:
            current_centroid = self.euclidean_centroid(data,label, index_i)
            centroid_list.append(current_centroid)
        max_cent_dist =  sy.spatial.distance.pdist(centroid_list,'euclidean').max()
        min_cent_dist = sy.spatial.distance.pdist(centroid_list,'euclidean').min()
        seperation = 0
        for c in centroid_list:
            seperation = seperation + 1 / sum(sy.spatial.distance.cdist([c], centroid_list)[0])
        dis = seperation * max_cent_dist / min_cent_dist
        
        return scat, dis
    
    def SD_valid_n(self, scat, dis, rango_init):
        index = self.num_k - rango_init
        return  max(dis) * scat[index] +    dis[index] 

    def SDbw(self, data,label) :
        scat = self.Scat(data, label)
        dens_bw = 0

        sij = 0
        for i in self.class_iter:
            s_i = 0 
            for j in self.class_iter:
                s_j = 0 
                if i == j:
                    continue
                else:
                    
                    eoc_i = self.element_of_clustert(data, label, i)
                    eoc_j = self.element_of_clustert(data, label, j)
                    centroid_i = self.euclidean_centroid(data, label,i)
                    centroid_j = self.euclidean_centroid(data, label, j)
                    stdev_i = self.cluster_stdev(eoc_i, label, False)
                    stdev_j = self.cluster_stdev(eoc_j, label, False)
                    w_eoc_i = 0
                    w_eoc_j = 0
                    for x in eoc_i:
                        if sy.spatial.distance.euclidean(x, centroid_i)<stdev_i:
                            w_eoc_i +=1
                    for x in eoc_j:
                        if sy.spatial.distance.euclidean(x, centroid_j) < stdev_j:
                            w_eoc_j +=1
                    if w_eoc_i > w_eoc_j:
                        weight = w_eoc_i
                    else:
                        weight = w_eoc_j
                    u_ij = (np.sum([self.euclidean_centroid(data, label, i), self.euclidean_centroid(data, label, j)], axis = 0)) / 2 
                    eoc_ij = np.append(eoc_i , eoc_j, axis = 0)
                    stdev_ij = np.sqrt(pow(stdev_i,2) + pow(stdev_j,2)) / 2
                    for x in eoc_ij:
                        d_ij =  sy.spatial.distance.euclidean(u_ij, x)
                        if d_ij < stdev_ij:
                            weighted_d_ij= d_ij / weight
                            s_j += weighted_d_ij
                s_i+=s_j
            sij +=s_i
        dens_bw = sij / (self.num_k * (self.num_k - 1))
        return (scat + dens_bw)

## Forma de hallar el indice validacion interno CVNN
def CVNN1(array_datos_pd, clgm):

    unique_labels1 = np.unique(clgm)
    k = len(unique_labels1)

    InterIndex = internalIndex(num_k=k, class_iter=unique_labels1)
    COM_aux , SEP_aux = InterIndex.CVNN(array_datos_pd, clgm)

    return COM_aux , SEP_aux, unique_labels1

def CVNN_n1(rango_init, rango_end_1, COM1, SEP1, unique_labels):

    CVNN_aux = []

    for i in range(rango_init, rango_end_1):
        id_aux = i-rango_init
        InterIndex = internalIndex(num_k=i, class_iter=unique_labels[id_aux])
        CVNN_aux.append(InterIndex.CVNN_n(COM1, SEP1, rango_init))
    
    return CVNN_aux

## Forma de hallar el indice validacion interno SD
def SD1(array_datos_pd, clgm):

    unique_labels1 = np.unique(clgm)
    k = len(unique_labels1)

    InterIndex = internalIndex(num_k=k, class_iter=unique_labels1)
    scat, dis = InterIndex.SD_valid(array_datos_pd, clgm)

    return scat, dis, unique_labels1

def SD_valid_n1(rango_init, rango_end_1, scat1, dis1, unique_labels):

    SD_aux = []

    for i in range(rango_init, rango_end_1):
        id_aux = i-rango_init
        InterIndex = internalIndex(num_k=i, class_iter=unique_labels[id_aux])
        SD_aux.append(InterIndex.SD_valid_n(scat1, dis1, rango_init))
    
    return SD_aux

def SSDD_index(df,label,l):         
  """
  Input:
  df : Data
  label: The cluster label corresponding to each row
  l : The number of nearest neighbors

  Return:
  SSDD index
  """
  u_labels = np.unique(label)
  if u_labels[0]==-1: u_labels=u_labels[1:] # use if we are not considering outliers
  cluster_list = []   
  for i in u_labels:
    if len(df[label==i])>l+1:
      cluster_list.append(df[label == i])

  n = len(cluster_list)         # The number of clusters

  # Part 1

  # Function to find the backbone points
  def find_backbone_points(C,l):
    backbone_points = []  # This list contains the index of the backbone points
    knn_list = [] # This list contains the information of nearest neighbors of each point in the cluster. 
    LD = [] # This list contains local density of each point in the cluster.
    knn = NearestNeighbors(n_neighbors=l+1) # Fit the nearest neighbors estimator from the training dataset.
    knn.fit(C)
    for i in range(len(C)):
      a = knn.kneighbors(C[i].reshape(1,-1))  # Finds the K-neighbors of a point and returns a            
      knn_list.append(a)                      # list containing indexes of those points  and the distances between the points.
      LD.append(l/a[0].sum()) # Adding Local density of each point to the list
    for i in range(len(C)): # Checking each point whether it is a backbone point
      ind = 0
      for j in range(1,l+1):
        if LD[i]>LD[knn_list[i][1][0][j]]:      # Condition for backbone point  # knn_list[i][1][0][j] gives the index of the nearest neighbor
          ind+=1
      if ind ==l:
        backbone_points.append(i)
    backbone_array = []     # This list contains the backbone points
    for i in backbone_points:
      backbone_array.append(C[i])
    backbone_array = np.array(backbone_array)
    return backbone_array, knn_list,backbone_points

  # Function to find the minimum spanning tree
  def minimum_spanning_tree(X, copy_X=True):
      """X are edge weights of fully connected graph"""
      if copy_X:
          X = X.copy()

      if X.shape[0] != X.shape[1]:
          raise ValueError("X needs to be square matrix of edge weights")
      n_vertices = X.shape[0]
      spanning_edges = []
      
      # initialize with node 0:                                                                                         
      visited_vertices = [0]                                                                                            
      num_visited = 1
      # exclude self connections:
      diag_indices = np.arange(n_vertices)
      X[diag_indices, diag_indices] = np.inf
      
      while num_visited != n_vertices:
          new_edge = np.argmin(X[visited_vertices], axis=None)
          # 2d encoding of new_edge from flat, get correct indices                                                      
          new_edge = divmod(new_edge, n_vertices)
          new_edge = [visited_vertices[new_edge[0]], new_edge[1]]                                                       
          # add edge to tree
          spanning_edges.append(new_edge)
          visited_vertices.append(new_edge[1])
          # remove all edges inside current tree
          X[visited_vertices, new_edge[1]] = np.inf
          X[new_edge[1], visited_vertices] = np.inf                                                                     
          num_visited += 1
      return np.vstack(spanning_edges)

   # BAVDens = The density of the region between a pair of adjacent vertices in MST of backbone points.
  def BAVDens_finder(edge_list, q, backbone_array, C):
    """
    Input
    edge_list: list of edges in the MST of a cluster
    q: array containing distance between backbone points
    backbone_array: array containing backbone points of a cluster
    C : a cluster
    """
    BAVDens = [] # This list contains the BAVDens of a cluster
    for i in range(len(edge_list)):
      point1 = edge_list[i][0]
      point2 = edge_list[i][1]
      radius = q[point1,point2]/2     # radius of the circle with each MST edges as a diameter.
      midpoint = (backbone_array[point1] + backbone_array[point2])/2 # midpoint
      count = 0
      for j in C:
        if (j[0]-midpoint[0])**2+(j[1]-midpoint[1])**2 <= radius**2:    # condition for points inside the circle
          count+=1
      BavDen = count/((2*radius)**2)    # power ==> dim represents the dimensionality of the input data space (2)
      BAVDens.append(BavDen)
    return BAVDens

  def backbone_point_pairs(backbone_array1,backbone_array2):
    """
    To find nearest backbone point pairs based on the condition
    Input: backbone arrays of two clusters
    Return: nearest backbone_point_pairss between two clusters based on the condition
    """
    backbone_point_pairss = []
    m = backbone_array1.shape[0]  # no of backbone points in cluster 1
    n = backbone_array2.shape[0]  # no of backbone points in cluster 2
    distance_matrix = np.zeros(shape=(m,n)) # array containing distance between two backbone points
    for i in range(m):
      for j in range(n):
        distance_matrix[i,j] = round(math.sqrt((backbone_array1[i][0] - backbone_array2[j][0])**2 + (backbone_array1[i][1] - backbone_array2[j][1])**2),2)
    
    # finding nearest backbone_point_pairs using given condiion
    for i in range(m):
      row_min = min(distance_matrix[i,:])
      itemindex = np.where(distance_matrix[i,:]==row_min)
      col = itemindex[0][0]     
      col_min = min(distance_matrix[:,col])
      if row_min == col_min:
        backbone_point_pairss.append((i,col))
    return backbone_point_pairss

  def find_distance(array1,array2):
    return round(math.sqrt((array1[0] - array2[0])**2 + (array1[1] - array2[1])**2),2)

  # finding inter-cluster nearest data pairs
  def find_index(backbone_point, cluster):
    """
    Finds the point in the cluster that is nearest to the backbone point
    """
    min_dist = 1000000
    index = None
    for i in range(len(cluster)):
      dist = find_distance(cluster[i],backbone_point)
      if dist < min_dist:
        min_dist = dist
        index = i
    return index

  backbone_array_list = [0]*n   # This list contains backbone points of each clusters as separate arrays
  qlist = [0]*n                 # This list contains distance between backbone points in a cluster 
  mst_edge_list = [0]*n         # This list contains the edges in the minimum spanning tree of each cluster 
  BAVDens_list = [0]*n          # This list contains BAVDens of each cluster
  DC=[0]*n                      # This list contains the density changes of a cluster along its backbone

  for i in range(n):
    for j in range(l,0,-1):
      backbone_array_list[i] = find_backbone_points(cluster_list[i],l=j)[0]
      if backbone_array_list[i].shape[0] < 2:
        continue
      else:
        break
    if backbone_array_list[i].shape[0] < 2:
      backbone_array_list[i] = np.array([cluster_list[i][0], cluster_list[i][1]])
    qlist[i] = squareform(pdist(backbone_array_list[i]))
    mst_edge_list[i] = minimum_spanning_tree(qlist[i])
    BAVDens_list[i] = BAVDens_finder(mst_edge_list[i], qlist[i], backbone_array_list[i], cluster_list[i])
    DC[i] = (max(BAVDens_list[i])-min(BAVDens_list[i]))/max(BAVDens_list[i])

  # Part 2
  backbone_point_pairs_list = [0]*n   # The list of nearest backbone point pairs of clusters.
  for i in range(n):
    backbone_point_pairs_list[i]= []
    for j in range(n):
      pair = backbone_point_pairs(backbone_array_list[i],backbone_array_list[j])
      if i!=j:
        backbone_point_pairs_list[i].append(pair)
      else:
        backbone_point_pairs_list[i].append(None)

  data_pairs_list = [0]*n        # The list of inter-cluster nearest data pairs
  for i in range(n):
    data_pairs_list[i]= [0]*n
    for j in range(n):
      data_pairs_list[i][j]=[]
      if backbone_point_pairs_list[i][j]== None:
        data_pairs_list[i][j].append(None)
      else:
        for k in backbone_point_pairs_list[i][j]:
          index1 = find_index(backbone_array_list[j][k[1]], cluster_list[i])  # finds the point in cluster i that is nearest to the backbone point in cluster j of the given backbone point pair k
          index2 = find_index(backbone_array_list[i][k[0]], cluster_list[j])
          data_pairs_list[i][j].append((index1,index2))

  ICD_list=[0]*n # This list contains ICDs of each cluster
  for i in range(n):
    ICD = 0
    for j in mst_edge_list[i]:
      ICD+=qlist[i][j[0],j[1]]
    ICD/= len(mst_edge_list[i])
    ICD_list[i]=ICD

  ICD_list = [0]*n   # This list contains ICDs of each cluster
  for cluster in range(n):
    _,b,c = find_backbone_points(cluster_list[cluster],min(len(cluster_list[cluster])-1,5))
    dist_list = [0]*len(c)
    for i in range(len(c)):
      dist_list[i]=[]
      near_points = []
      for j in b[i][1][0]:
        near_points.append(cluster_list[cluster][j].tolist())
      dist_matrix = np.array(squareform(pdist(near_points)))
      mst = minimum_spanning_tree(dist_matrix)
      for k in range(len(mst)):
            dist_list[i].append(dist_matrix[mst[k][0],mst[k][1]])
    l = [item for sublist in dist_list for item in sublist]
    ICD_list[cluster] = mean(l)

  mean_BNPDens = [0]*n # This list contains mean density of the region between Ci and all other clusters
  count_list = []
  for c in range(n):
    BNPDens_list=[]
    for d in range(n):
      if c!=d:
        for i in data_pairs_list[c][d]:
          if i==None: continue
          else:
            point1 = cluster_list[c][i[0]]
            point2 = cluster_list[d][i[1]]
            midpoint = (point1 + point2)/2 
            radius = min(ICD_list[c],ICD_list[d])/2
            count = 0
            for k in cluster_list[c]:
              if (k[0]-midpoint[0])**2+(k[1]-midpoint[1])**2 <= radius**2:
                count+=1  
            for k in cluster_list[d]:
              if (k[0]-midpoint[0])**2+(k[1]-midpoint[1])**2 <= radius**2:
                count+=1
            BNPD = count/((2*radius)**2)
            BNPDens_list.append(BNPD)
    mean_BNPDens[c] = mean(BNPDens_list)

  DR=[0]*n # This list contains inner-cluster density ratio of each clusters
  for i in range(n):
    DR[i] = mean_BNPDens[i]/max(mean_BNPDens[i],mean(BAVDens_list[i]))

  def SSDD(DC, DR, alpha):
    """
    DC: inner-cluster validation measure
    DR: Iinter-cluster validation measure
    alpha: parameter
    """
    beta = 1-alpha
    index_list = [0]*n
    for i in range(n):
      index_list[i] = alpha*DC[i] + beta*DR[i]
    SSDD_index = sum(index_list)/n
    return SSDD_index
  SSDD_index = SSDD(DC, DR, alpha=.5)

  return SSDD_index

  